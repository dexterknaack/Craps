
/**
 * Write a description of class DieToStringTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DieToStringTester
{
    public static void main(String[] args)
    {
        Die d1 = new Die();
        d1.roll();
        System.out.println(d1);
        d1.roll();
        System.out.println(d1);
        d1.roll();
        System.out.println(d1);
    }
}
